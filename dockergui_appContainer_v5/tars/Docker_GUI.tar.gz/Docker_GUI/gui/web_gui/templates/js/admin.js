/*!
 * This file is part of the DockerGUI software
 * Copyright (c) 2014 Alex Zhong, Bob Chen
 * 
 * License: LGPLv3 (http://www.gnu.org/licenses/lgpl.html)
*/

var pwdFocus = false;

$(document).ready(function(){
	$("#add").click(function(){	
		//verify input
		var Pwd = $.trim($("#pwd").val());
		var Host = $.trim($("#host").val());
		var Port = $.trim($("#port").val());
		
		ajaxClient.loadData('/addhost/', 'POST', {pwd:Pwd,host:Host,port:Port},
				function(jsondata){
					if(jsondata.errorcode != 0){
						modalAlert("Add Failed", jsondata.errormsg, function(){
							hideModalAlert();
						});
					} else {
						modalAlert("Add OK", Host, function(){
							hideModalAlert();
						});
					}
				}
		)
	});
   
    $("#pwd").focusin(function(){
    	pwdFocus = true;
    });
    $("#pwd").blur(function(){
    	pwdFocus = false;
    });
    $(window.document).keydown(function(ev){
    	if(ev.keyCode === 13 && pwdFocus){
    		$("#add").click();
    		return false; // prevent browser-self event
    	}
    });
	
});


