/*!
 * This file is part of the DockerGUI software
 * Copyright (c) 2014 Alex Zhong, Bob Chen
 * 
 * License: LGPLv3 (http://www.gnu.org/licenses/lgpl.html)
*/

var glbResource = {};
var glbHistory = {};
var glbRepository = "undefined";
var glbMaintainer = "";
var glbWorkId = "";  // use to save status and generate file
var glbTag = "";
var currId = "";	// use to build image

var syncSteps = [];
var syncStatus = "idle"; // idle:no sync; runing:syncing
var needSync = false;

var refreshTimer = "";
var autoRefreshInterval = 2000;

var searchFocus = false;
var gitSearchFocus = false;

var enterContainerCmd = "ln -sf /bin/bash /bin/entercontainer";

var glbFileData = null;

var gitHubResPerPage = 10;
var gitHubResMaxPage = 100;

$(document).ready(function(){
	
	searchResources();
	getHistory();
	
	loadWorkStatus();
	
	initPage();
	
	$("#content").show();
//	$("#resPanel").hide();
//	$("#work-res-title").hide();
	
    $("#component .jq-draggable-outcontainer").draggable({
        connectToSortable : "#content",
    	helper: "clone",
		revert: "invalid",
        stop: function (event, ui) {
        	//console.log(event.target)
            //   debugger;
        }
    });
    
    var sortUpdateFlag = false;
    $("#content").sortable({
    	revert: true,
    	cancel: ".stop-drag",
    	start: function(event, ui){
    		sortUpdateFlag=true;
    	},
    	receive: function(event, ui){
    		sortUpdateFlag=false;
    	},
    	update:function(event,ui){
    		if(sortUpdateFlag){
    			// the first element must be base image
    			if($("#content .jq-draggable-incontainer:first").hasClass("image")){  
    				previewGenerator();
    			} else {
    				changeBaseImageFn($("#content .stop-drag"), false);
    			}
    		}
    	}
    });

    $("#content").droppable({
        drop: function (event, ui) {
            if (ui.draggable[0].className.indexOf("jq-draggable-outcontainer") > 0) {
				console.log(ui.draggable[0])
				var target = $(ui.draggable[0]);
				target.removeClass("jq-draggable-outcontainer");
				target.addClass("jq-draggable-incontainer");
				
				if(target.hasClass("cmd")){
					var targetAttr = target.attr("attr");
					if(targetAttr === "run"){
						var isGithubRes = target.hasClass("github");
						modalAlert("Action RUN command", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}

							if(isGithubRes){ // github resource use run git clone cmd
								$(".item-tag", target).text("RUN");
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
						
						var resId = target.attr("itemid");
						if(isGithubRes && resId){
							var itemUrl = glbResource[resId].imageurl;
							$("#runarea").val("git clone " + itemUrl);
						}
						
					} else if(targetAttr === "cmd"){
						
						modalAlert("Action CMD command", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
					}else if(targetAttr === "expose"){
						
						var exposeTmpl = "<div class='expose-chk-group'>";
						for (chkItem in Expose_CheckBox_Conf) {
							exposeTmpl += "	<label><input type='checkbox' class='expose-chk' value='{0}'/> {0}-{1}</label>".format(chkItem, Expose_CheckBox_Conf[chkItem])
						}
						exposeTmpl += "</div>";
						
						modalAlert("Action EXPOSE command", '<textarea id="runarea" class="form-control"></textarea>' + exposeTmpl, function(){
							//console.log($("#runarea").val());
							var value = $("#runarea").val();
							if($.trim(value) == ""){
								setAlertErrMsg();
								return false;
							} else if(/^[0-9\s]+/.test($.trim(value)) === false || /[\n]/.test($.trim(value)) ) {
								setAlertErrMsg("Invalid ");
								return false;
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
						
						$(".expose-chk-group .expose-chk").unbind().change(function(){
							var currValue = $(this).val();
							var isChecked = $(this).is(":checked");
							var exposeArrey = $("#runarea").val().split(/\s+|\n/);
							//console.log(exposeArrey)
							if(isChecked){
								var exists = false;
								for(var i=0; i<exposeArrey.length; i++) {
									var tmp = $.trim(exposeArrey[i]);
									if(tmp === currValue){
										exists = true;
									}
								}
								if( !exists ){
									exposeArrey.push(currValue);
								}
							} else {
								for(var i=0; i<exposeArrey.length; i++) {
									var tmp = $.trim(exposeArrey[i]);
									if(tmp === currValue){
										exposeArrey.splice(i,1);
									}
								}
							}
							
							$("#runarea").val(exposeArrey.join(" "));
						});
						
					}else if(targetAttr === "entrypoint"){
						
						modalAlert("Action ENTRYPOINT command", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
					}else if(targetAttr === "volume"){
						
						modalAlert("Action VOLUME command", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
					}else if(targetAttr === "user"){
						
						modalAlert("Action USER command", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
					}else if(targetAttr === "workdir"){
						
						modalAlert("Action WORKDIR command", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
					}else if(targetAttr === "onbuild"){
						
						modalAlert("Action ONBUILD command", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
					}else if(targetAttr === "env"){
						
						modalAlert("Action ENV command", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}
							$(".item-comm", target).text($("#runarea").val());
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
					}else if(targetAttr === "comments"){
						
						modalAlert("Add comments", '<textarea id="runarea" class="form-control"></textarea>', function(){
							//console.log($("#runarea").val());
							if($.trim($("#runarea").val()) == ""){
								setAlertErrMsg();
								return false;
							}
							$(".item-comm", target).text($("#runarea").val().split("\r\n").join(""));
							target.data('cmd', $("#runarea").val());
						}, "", 
						function(){
							target.remove();
						});
					}else if(targetAttr === "add"){
						var bodyHtml = '<form class="form-horizontal" role="form">' + 
											'<div class="form-group">' +
											' <label for="inputSrc" class="col-sm-3 control-label">Source</label>' +
											'<div class="col-sm-9">' + 
											'<input type="text" class="form-control" id="inputSrc" placeholder="Source">' + 
											'</div></div>' +
											'<div class="form-group">' + 
											'<label for="inputDest" class="col-sm-3 control-label">Destination</label>' +
											'<div class="col-sm-9">' +
											'<input type="text" class="form-control" id="inputDest" placeholder="Destination">' +
											'</div></div></form>';
						

						modalAlert("Action ADD command", bodyHtml, function(){
							//console.log($("#inputSrc").val());
							//console.log($("#inputDest").val());
							if($.trim($("#inputSrc").val()) == "" || $.trim($("#inputDest").val()) == ""){
								setAlertErrMsg("Source or Destination is required.");
								return false;
							}
							$(".item-tag", target).text("ADD");
							$(".item-comm", target).text($("#inputSrc").val() + " " + $("#inputDest").val());
							target.data('src', $("#inputSrc").val());
							target.data('dest', $("#inputDest").val());

						}, "", 
						function(){
							target.remove();
						});
						
						//$(".thumb-icon", target).addClass("file");
						
						var resId = target.attr("itemid");
						if(resId){
							var itemUrl = glbResource[resId].imageurl;
							$("#inputSrc").val(itemUrl);
						}

					}
				} else {					
					if($("#content .image").length > 2){ // the length > 1, is count on itself and the helper element
						modalAlert("", 'Do you need to replace the base image?', function(){
							changeBaseImageFn(target, true);
						}, "Replace", 
						function(){
							target.remove();
						});
					} else {
						changeBaseImageFn(target, false);
					}
				}
				
            }
        }
    });
	
    
	$("#btn_build").click(function(){
		
		// no base image cannot build
		if($("#content .image").length < 1){
			modalAlert("Failed", 'Base Image is required.' ,function(){
				hideModalAlert();
			});
			return;
		}
		
		
		var data = getBuildInfo();
		
		showLoading('Generating DockerFile', function(){
			ajaxClient.loadData('/genFile/', 'POST', 
				{id:glbWorkId, repository:glbRepository, tag:glbTag, steps:JSON.stringify(data)},
				function(jsondata){
					//console.log(jsondata.errorcode)
					hideLoading();
					if(jsondata.errorcode == 0){
						currId = jsondata.id;
						showFile(jsondata.file);
					} else {
						modalAlert("Failed", "Failed",function(){
							hideModalAlert();
						});
					}
				});
		});
		
	});
	
	$("#showRes").click(function(){
		$("#contentDiv").hide();
		$("#resPanel").show();
		$("#inputUrl").val($("#resInput").val());
		$("#inputDisName").val("");
		$("#inputComment").val("");
		//$("#autoPull").val("");
		$("#work-res-title").show();
		$("#work-title").hide();
		
		$("#disNameGroup").hide();
		$("#fileGroup").hide();
		$("#gitGroup").hide();
		$("#inputUrl").removeAttr("disabled");
		$("#autoPull").removeAttr("disabled").removeAttr("checked").parent().show();
		$("#urlImage").text("Image Name");
		
		$("#sourceType").val("registry");
	});
    
	$("#searchRes").click(function(){
		$("#resourceBody").html("");
		searchResources($("#resInput").val());
	});

	$("#searchHistory").click(function(){
		$("#historyBody").html("");
		getHistory($("#historyInput").val());
	});
	
    $("#cancelAddRes").click(function(){
		$("#contentDiv").show();
		$("#resPanel").hide();
		$("#work-res-title").hide();
		$("#work-title").show();		
    });
    
    $("#addRes").click(function(){
    	addResource();
    });
    
    $("#content").delegate(".jq-draggable-incontainer", "click", function(){
    	$(".itemClicked").removeClass("itemClicked");
    	$(this).addClass("itemClicked");
    	
    	showProperties($(this));
    });
    
    $("#content").delegate(".jq-draggable-incontainer", "dblclick", function(){
    	editCmd($(this));
    });
    
    $("#content").delegate(".delete", "click", function(ev){
    	var item = $(this).parent().parent();
    	if(item.hasClass("itemClicked")){
    		// clear properties
    		$("#propertiesInfo").html("");
    	}
    	item.remove();
    	previewGenerator();
    	ev.stopPropagation();
    });
    
    $("#resourceBody").delegate(".delete", "click", function(ev){
    	var item = $(this).parent().parent();
    	toDeleteResource(item);
    	ev.stopPropagation();
    });
 
    $("#historyBody").delegate(".delete", "click", function(ev){
    	var item = $(this).parent().parent();
    	toDeleteHistory(item);
    	ev.stopPropagation();
    });    
    
    $("#historyBody").delegate(".dockerFile", "click", function(ev){
    	var item = $(this);
    	var fileId = item.attr("itemid");
    	var historyId = item.attr("historyid");
    	var itemName = item.attr("attr");

    	$(".itemClicked").removeClass("itemClicked");
    	item.addClass("itemClicked");
    	
    	showHistoryFile(fileId,historyId, itemName);
    	ev.stopPropagation();
    });
    
    $("#resourceBody").delegate(".jq-draggable-outcontainer", "click", function(ev){
    	var item= $(this);
    	$(".itemClicked").removeClass("itemClicked");
    	item.addClass("itemClicked");
    	
    	showProperties(item, true);
    	ev.stopPropagation();
    });

    $(".search-res-panel").delegate(".repo-list-item", "click", function(ev){
    	var item= $(this);
    	$(".itemClicked").removeClass("itemClicked");
    	item.addClass("itemClicked");

    	showProperties(item, true);
    	ev.stopPropagation();
    });
    
    $("#editTagName").click(function(){

    	//$("#modalEditTag").modal('show');
    	var workspaceHead = $(".workspace-head");
    	if(workspaceHead.hasClass("edit")){ //save chagne
    		if($("#inputTagName, #inputVersion").hasClass("err")){
    			return;
    		}
    		
    		glbRepository = $("#inputTagName").val() || "undefined";
        	glbMaintainer = $("#inputMaintainer").val();
        	glbTag = $("#inputVersion").val();
        	
        	$(".repo-dis").text(glbRepository + (glbTag ? ":"+glbTag : "" ));
        	$(".mantainer-dis").text(glbMaintainer);
    		workspaceHead.removeClass("edit");
    		previewGenerator();
    	} else { // enable edit
        	$("#inputTagName").val(glbRepository);
        	$("#inputMaintainer").val(glbMaintainer);
        	$("#inputVersion").val(glbTag);
        	$("#inputTagName, #inputVersion").removeClass("err");
    		workspaceHead.addClass("edit");
    	}
    });
    
//    $("#editTag").click(function(){
//    	glbRepository = $("#inputTagName").val() || "undefined";
//    	glbMaintainer = $("#inputMaintainer").val();
//    	glbTag = $("#inputVersion").val();
//    	
//    	$("#tagNameItem").text(glbRepository);
//    	$("#modalEditTag").modal('hide');
//    	previewGenerator();
//    });
        
    $("#btn_registry").click(function(){
    	loadRegistryList();
    	$("#newRegPanel").hide();
    	$("#modalRegistry").modal('show');
    });
    
    $("#newReg").click(function(){
    	$("#newRegPanel").toggle();
    });
    
    $("#addRegistry").click(function(){
    	var host = $("#inputHost").val();
    	var port = $("#inputPort").val();
    	var pushUser = $("#inputPushUser").val();
    	var pushPwd = $("#inputPushPwd").val();
    	var pushEmail = $("#inputPushEmail").val();
    	
    	toAddRegistry(host, port, pushUser, pushPwd, pushEmail);
    });

    $("#regList").delegate(".reg-delete", "click", function(ev){
    	return;
    	var regId = $(this).attr("attr");
    	deleteRegistry(regId);
    });
    
    $("#tabBar .history-tab").click(function(){
		$("#resPanel").hide();
		$("#work-res-title").hide();

    	$("#contentDiv, #work-title").hide();
    	$("#content-history, #his-work-title").show();
    });
    $("#tabBar .res-tab, #tabBar .cmd-tab").click(function(){
		$("#resPanel").hide();
		$("#work-res-title").hide();

    	$("#contentDiv, #work-title").show();
    	$("#content-history, #his-work-title").hide();
    	previewGenerator();
    });
    
    $("#clnWorkSpace").click(function(){
    	$("#content").html("");
    	
		glbRepository = "undefined";
		glbTag = "";
		$("#work-title .repo-dis").text(glbRepository);
		$("#inputTagName").val(glbRepository);
		$("#inputVersion").val(glbTag);
    	previewGenerator();
    });
    
    /***
     * File upload
     */
    $("#fileuploadBtn").click(function(){
    	$("#fileupload").click();
    });
    $("#fileupload").fileupload({
    	url: '/addResource/',
    	dataType: 'json',
    	//formData: {"a":'1', "b":'2'},
    	add: function(e, data){
    		//console.log(data);
    		var fileName = data.files[0].name;
    		$("#inputUrl").val(fileName);
    		$("#inputDisName").val(fileName);
    		glbFileData = data;
    		//$("#fileupload").fileupload('option', 'formData', {"a":"123123"});
    		//data.submit();
    	},
    	progressall: function(e, data){
    		var progress = parseInt(data.loaded / data.total *100, 10);

    		$("#progress").text(progress + "%");
    		$("#progress").attr("aria-valuenow", progress+"");
    		$("#progress").attr("style","width:{0}%".format(progress));    		
    	},
    	done: function(e, data){
    		//console.log(data.result)
    		if(data.result.errorcode == 0){
    			searchResources();
    		} else {
    			$("#progress").addClass("progress-bar-danger");
    			$("#progress").text(data.result.errormsg);
    		}
    		
			$("#progressBtn").unbind()
							 .click(function(){
								 $("#modalProgress").modal('hide');
								 if(data.result.errorcode == 0){
									 $("#cancelAddRes").click();
								 }
							 })
							 .show();
    	}
    });
    
    
    /***
     * Search from github
     ***/
    $("#searchGithubBtn").click(function(){

        var gitHubusername = $(".top-user-style[githubuser]").attr("githubuser");
        var checkbox = $("#searchYourself");
        if(gitHubusername == "" || gitHubusername == null || gitHubusername == "None"){
            checkbox.attr("disabled","disabled");
            checkbox.parent().addClass("label-disabled");
        }
    	$("#modalGithub").modal('show');
    });
    $("#searchGithub").click(function(){
    	searchResFromGithub($.trim($("#githubInput").val()),$('#searchYourself').is(':checked'));
    });
    $("#githubResList").delegate(".btn-add-git-res", "click", function(ev){
    	var repoItem = $(this).parent().parent(),
    		gitUrl = repoItem.attr("giturl"),
    		repoName = $(".span-git-repo", repoItem).text(),
    		repoDescription = $(".repo-list-item-description", repoItem).text();
    	
    	addGitHubRes(gitUrl, repoName, repoDescription);	
    });
    
    
    $("#inputTagName, #inputVersion").keyup(function(){
    	if(/[^a-z0-9-_.]/.test($(this).val())){
    		$(this).addClass("err");
    	} else {
    		$(this).removeClass("err");
    	}
    });
   
    
    // Search support Enter
    $("#resInput").focusin(function(){
    	searchFocus = true;
    }).blur(function(){
    	searchFocus = false;
    });
    $("#githubInput").focusin(function(){
    	gitSearchFocus = true;
    }).blur(function(){
    	gitSearchFocus = false;
    });
    
    $(window.document).keydown(function(ev){
    	if(ev.keyCode === 13){
    		if(searchFocus){
    			$("#searchRes").click();
    		} else if (gitSearchFocus){
    			$("#searchGithub").click();
    		}
    		return false; // prevent browser-self event
    	}
    });
    
    // No Copy
    $(window.document).delegate(".nc", "copy", function(ev){
    	return false;
    });
    
    $(window).bind('beforeunload',function(){
    	if(syncStatus==="running"){
    		return 'Saving work status，are you sure to leave this page？';
    	}
    });

});

function initPage(){
	glbMaintainer = $("#inputMaintainer").val();
	$("#previewBody").val("");
}


function getBuildInfo(){
	var items = $("#content .jq-draggable-incontainer");
	console.log(items);
	
	var steps = [];
	for(var i=0; i<items.length; i++){
		var item = $(items[i]);
		var itemAttr = item.attr("attr");
		if(item.hasClass("image")){
			steps.push({ 'FROM':itemAttr });
		} else if(item.hasClass("cmd")) {
			var tmp = {};
			if(itemAttr === 'add'){
				tmp['ADD'] = { 'src':item.data('src'), 'dest':item.data('dest') };
				steps.push(tmp);
			} else if (itemAttr === 'run'){
				steps.push({ 'RUN':item.data('cmd') });
			} else if (itemAttr === 'cmd'){
				steps.push({ 'CMD':item.data('cmd') });
			} else if (itemAttr === 'expose'){
				steps.push({ 'EXPOSE':item.data('cmd') });
			} else if (itemAttr === 'volume'){
				steps.push({ 'VOLUME':item.data('cmd') });
			} else if (itemAttr === 'entrypoint'){
				steps.push({ 'ENTRYPOINT':item.data('cmd') });
			} else if (itemAttr === 'user'){
				steps.push({ 'USER':item.data('cmd') });
			} else if (itemAttr === 'workdir'){
				steps.push({ 'WORKDIR':item.data('cmd') });
			} else if (itemAttr === 'env'){
				steps.push({ 'ENV':item.data('cmd') });
			} else if (itemAttr === 'comments'){
				var tmpcomment = item.data('cmd');
				tmpcomment = tmpcomment.split("\r\n").join("");
				tmpcomment = tmpcomment.replace(/\n/g,' ');				
				steps.push({ '#':tmpcomment });				
			} else if (itemAttr === 'onbuild'){
				steps.push({ 'ONBUILD':item.data('cmd') });
			}
		}
		if(i === 0 && glbMaintainer !== ""){
			// Set Maintainer Item in index 1
			steps.push({'MAINTAINER':glbMaintainer});
		}
	}
	
	// Add symbol link
	if(items.length > 0){
		steps.push({'RUN':enterContainerCmd});
	}
	
	console.log(steps);
	return steps;
}


function showFile(rowList)
{
	var fileText = "";
	fileText = rowList.join(getJoinToken());
	
	modalAlert("DockerFile Review", '<textarea id="fileBody" class="form-control" readonly></textarea>', function(){
		hideModalAlert();
		
		$("#btn_build").attr("disabled", "disabled");
				
		//$("#outputInfo").html("");
		setTimeout(function(){
			ajaxClient.loadData('/buildImage/', 'POST', {id:currId, repository:glbRepository, tag:glbTag},
					function(jsondata){
//						$("#btn_build").removeAttr("disabled");
						getHistory();

						if(jsondata.errorcode == 0){
							//searchResources();
							refreshTimer = window.setInterval(function(){
								console.log("check build status: " + currId)
								queryBuildStatus(currId);
							},  autoRefreshInterval);
							
							// Generate a new work id.
							getBuildId(true);
							
						} else {
							modalAlert("Failed", jsondata.errormsg,function(){
								hideModalAlert();
							});
						}
					}
			)
		},
		500
		);
		
	}, "Continue");
	
	$("#fileBody").val(fileText);
}

function queryBuildStatus(fileId)
{
	ajaxClient.loadData('/buildStatus/', 'GET', 
			{fileId:fileId},
			function(jsondata){
				//$("#btnPush").removeAttr("disabled");
				if(jsondata.errorcode == 0){
					var status = jsondata.status.status;
					
					var outputTitle = "Success";
					if(status === "failed"){
						outputTitle = "Failed";
						$("#btn_build").removeAttr("disabled");
						window.clearInterval(refreshTimer);
					} else if (status === "running") {
						console.log("Build is running");
					} else if (status === "finished") {
						console.log("Build is finished");
						window.clearInterval(refreshTimer);
						$("#btn_build").removeAttr("disabled");
					}
					
					if(jsondata.output.length > 0){
						
						getHistory();
						searchResources();
						
						var outputList = [];
						if(jsondata.output.length > 0){
							for(var i=0; i<jsondata.output.length; i++){
								outputList.push(jsondata.output[i]);
								//outputList.push(jsondata.output[i].replace('\\u003e','>'));
							}
						}
						
						modalAlert(outputTitle, '<textarea id="fileBody" class="form-control" readonly></textarea>' ,function(){
							hideModalAlert();
						});
						
						$("#fileBody").val(formatOutput(outputList));
					}
					
				} else {
					modalAlert("Failed", jsondata.errormsg, function(){
						hideModalAlert();
						return false;
					});
				}
			}
		);
}


function searchResources(kw, toHideLoading)
{
	if(typeof kw === "undefined"){
		kw = "";
	}
	
	ajaxClient.loadData('/searchResources/', 'GET', {keyword:kw},
		function(jsondata){			
			var tmpl = '<div class="window jq-draggable-outcontainer {0}" attr="{1}" itemid="{2}" >' +
		                '<div class="thumb-icon"></div>' +
						'<div class="item-body"><span class="item-tag">{3}</span><span class="item-comm"></span></div>' +
						'<div class="item-tool"><span class="delete"></span><span class="arrow-right"></span></div>' +
					   '</div>';
			
			var resHtml = "";
			
			if(jsondata.errorcode == 0){	
				var resourceList = jsondata.resources;
				
				for(var i=0; i < resourceList.length; i+=1){
					
					var item = resourceList[i],
						divCss = "image", // image, file
						attr = item.name,
						itemid = item.resid,
						itemType = item.type,
						displayStr = item.name;

					glbResource[itemid] = item;
					
					if(itemType !== "registry") {
						divCss = "cmd " + itemType;
						if(itemType === "github"){
							attr = "run";
						} else {
							attr = "add";
						}
						//attr = "add";
					}
					
					var html = tmpl.format(divCss, attr, itemid, displayStr);
					//console.log(html);
					resHtml += html;						
				}
				
			} else {
				// error handle
			}

			if(toHideLoading){
				hideLoading();
			}
			
			$("#resourceBody").html(resHtml);
		    $("#resources .jq-draggable-outcontainer").draggable({
		        connectToSortable : "#content",
		    	helper: "clone",
				revert: "invalid",
		        stop: function (event, ui) {
		        	//console.log(event.target)
		            //   debugger;
		        }
		    });
		}
	);
}


function addResource()
{
	var sourceType = $("#sourceType").val();
	var itemUrl = $("#inputUrl").val();
	var displayName = $("#inputDisName").val();
	var comment = $("#inputComment").val();
	var autoPulltag;

	if (itemUrl == "" ) {
		$("#inputError").html("You must provide an Image Name.");
		return false;
	}

	if (displayName == "") {
		displayName = itemUrl;
	}
	$("inputError").html("");	
	if (document.getElementById("autoPull").checked) {
		autoPulltag = "True";
	} else {
		autoPulltag = "False";
	}
	
	if(sourceType == "registry"){
		displayName = itemUrl;
	}

	if(sourceType != "localfile"){
		showLoading('Adding Resource', function(){
			ajaxClient.loadData('/addResource/', 'POST', {srcType:sourceType, url:itemUrl, autoPull:autoPulltag,displayName:displayName, comment:comment},
				function(jsondata){
					console.log(jsondata.errorcode)
					//hideLoading();
					if(jsondata.errorcode == 0){
						searchResources("", true);
						$("#cancelAddRes").click();
					} else {
						hideLoading();
					}
				});
		});
		
	} else {
		$("#progress").text("0%");
		$("#progress").attr("aria-valuenow", "0");
		$("#progress").attr("style","width:0%");
		$("#progressBtn").hide();
		$("#modalProgress").modal('show');

		$("#fileupload").fileupload('option', 'formData', {srcType:sourceType, url:itemUrl, autoPull:autoPulltag,displayName:displayName, comment:comment});
		glbFileData.submit();
	}
	

}


function showProperties(item, inResource)
{
	var itemAttr = item.attr("attr");
	var itemId = item.attr("itemid");
	var itemType = "cmd";
	if(item.hasClass("image")){
		itemType = "image";
	}
	
	var infoHtml = ""
	var tmpl = "";
	
	// Item is cmd
	if(itemType === "cmd"){
		//var itemComm = $(".item-comm", target).text();
		if(itemAttr === "run"){
			tmpl = "<div class='propName'>RUN</div><div class='propAttr'>{0}</div>";
			
			var cmdProperty = item.data('cmd');
			if(item.hasClass("github")){
				cmdProperty = "git clone " + glbResource[itemId].imageurl;
			}
			infoHtml = tmpl.format(cmdProperty);
			
		} else if (itemAttr === "add"){
			if(inResource){
				console.log(glbResource[itemId]);
				var sourceItem = glbResource[itemId];
				tmpl = "<div class='propName'>{0}</div>" +
				"<div class='propAttr'>Source Type:</div><div>{1}</div>" +
				"<div class='propAttr'>URL/Name:</div><div>{2}</div>" +
				"<div class='propAttr'>Comment:</div><div>{3}</div>";
				
				infoHtml = tmpl.format(sourceItem.name, sourceItem.type, sourceItem.imageurl, sourceItem.comment);
			} else {
				tmpl = "<div class='propName'>ADD</div><div class='propAttr'>Source:</div><div>{0}</div><div class='propAttr'>Destination:</div><div>{1}</div>";
				infoHtml = tmpl.format(item.data('src'), item.data('dest'));
			}

		}else if (itemAttr === "cmd"){
			tmpl = "<div class='propName'>CMD</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd'));

		}else if (itemAttr === "expose"){
			tmpl = "<div class='propName'>EXPOSE</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd'));

		}else if (itemAttr === "entrypoint"){
			tmpl = "<div class='propName'>ENTRYPOINT</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd'));

		}else if (itemAttr === "volume"){
			tmpl = "<div class='propName'>VOLUME</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd'));

		}else if (itemAttr === "user"){
			tmpl = "<div class='propName'>USER</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd'));

		}else if (itemAttr === "workdir"){
			tmpl = "<div class='propName'>WORKDIR</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd'));

		}else if (itemAttr === "env"){
			tmpl = "<div class='propName'>ENV</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd'));

		}else if (itemAttr === "onbuild"){
			tmpl = "<div class='propName'>ONBUILD</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd'));

		}else if (itemAttr === "comments"){
			tmpl = "<div class='propName'>COMMENTS</div><div class='propAttr'>{0}</div>";
			infoHtml = tmpl.format(item.data('cmd').split("\r\n").join(""));
	
		}
		//console.log(infoHtml);
		$("#propertiesInfo").html(infoHtml);
		return true;
	}

	// item is image
	ajaxClient.loadData('/getProperty/', 'GET', {resid:itemAttr},
		function(jsondata){		
			if(jsondata.errorcode == 0){
				var info = jsondata.property;
								
				tmpl = "<div class='propAttr'><span class='prop-icon prop-author'></span><span class='prop-info'>{0}</span></div>" +
				//"<div class='propAttr'><span class='prop-icon prop-build'></span><span class='prop-info'>{1}</span></div>" +
				"<div class='propAttr'><span class='prop-icon prop-id'></span><span class='prop-info'>{1}</span></div>" +
				"<div class='propAttr'><span class='prop-icon prop-date'></span><span class='prop-info'>{2}</span></div>" +
				"<div class='propAttr'><span class='prop-icon prop-size'></span><span class='prop-info'>{3}</span></div>";
				
				infoHtml = tmpl.format(info.author, info.id, new Date(info.created).toLocaleString(), JqConvertCapacity(info.Size));
			} else {
				infoHtml = "Failed to get properties."
			}
			
			$("#propertiesInfo").html(infoHtml);
		}
	);
	
}


function getHistory(kw)
{
	if(typeof kw === "undefined"){
		kw = "";
	}

	ajaxClient.loadData('/getHistory/', 'GET', {keyword:kw},
			function(jsondata){			
				var tmpl = '<div class="window jq-draggable-outcontainer {0}" attr="{1}" itemid="{2}" historyid="{3}">' +
			                '<div class="thumb-icon {5}"></div>' +
							'<div class="item-body"><span class="item-tag">{4}</span><span class="item-comm"></span></div>' +
							'<div class="item-tool"><span class="delete"></span><span class="arrow-right"></span></div>' +
						   '</div>';
				
				var resHtml = "";
				var status_icon = "";
				
				if(jsondata.errorcode == 0){
					var historyList = jsondata.history;
					
					for(var i=0; i < historyList.length; i+=1){
						
						var item = historyList[i],
							divCss = "dockerFile",
							attr = item.resid,
							itemid = item.fileid,
							historyid = item.id,
							displayStr = item.resid;
							status = item.status;
							if(status === "failed"){
								status_icon = "thumb-failed-icon";
							} else if (status === "running") {
								console.log("Build is running");
								status_icon = "thumb-setting-icon";								
							} else if (status === "finished") {
								console.log("Build is finished");
								status_icon = "thumb-success-icon";
							}

						glbHistory[itemid] = item;
						
						var html = tmpl.format(divCss, attr, itemid,historyid,displayStr,status_icon);
						//console.log(html);
						resHtml += html;						
					}
					
				} else {
					// error handle
				}

				$("#historyBody").html(resHtml);
			}
		);
}

function showHistoryFile(fileId, historyId, itemName)
{
	var infoHtml = "";
	var tmpHtml = "";

	infoHtml = 'See more details?You could check the <a href=\'#\' id=\'link_output\' style="target-new:none;" class="alert-link">Build Output.</a><br/><br/>';

	ajaxClient.loadData('/getFile/', 'GET', {fileid:fileId},
			function(jsondata){
				if(jsondata.errorcode == 0){
					tmpHtml = jsondata.file[0];
					tmpHtml = "<div class='nc'>" + tmpHtml.join("<br/>") + "</div>";
					infoHtml = infoHtml + tmpHtml;
					$("#propertiesInfo").html(infoHtml);
					
					$("#previewBody").val(formatOutput(jsondata.file[0]));
					
					var repoName = "";
					var repoTag = "";
					var index = itemName.lastIndexOf(":");
					if(index === -1){
						repoName = itemName;
					} else {
						repoName = itemName.substring(0, index);
						repoTag = itemName.substring(index+1);
					}
					
					restoreWorkStatus(jsondata.file[1], repoName, repoTag, true);
					
					$("#link_output").click(function(){
						$("#propertiesInfo").hide();
						$("#outputInfo").show();
						ajaxClient.loadData('/getHistoryOutput/', 'GET', {historyid:historyId},
								function(jsondata){
									if(jsondata.errorcode == 0){
										var tmpHtml = "";
										var infoHtml = '<a href=\'#\' id=\'link_file\' style="target-new:none;" class="alert-link">Back</a><br/><br/>';
										var outputList = [];
										if(jsondata.output.length > 0){
											for(var i=0; i<jsondata.output.length; i++){
												outputList.push(jsondata.output[i]);
											}
										}
										//$("#fileBody").val(formatOutput(outputList));
										//tmpHtml = jsondata.output;
										//tmpHtml = tmpHtml.join("<br/>");
										tmpHtml = formatOutput(outputList,true);
										infoHtml = infoHtml + tmpHtml;
										$("#outputInfo").html(infoHtml);
										$("#link_file").click(function(){
											$("#propertiesInfo").show();
											$("#outputInfo").hide();											
										});
									} else {
										// error handle
									}
								}
							);
					});

				} else {
					// error handle
				}
			}
		);
	$("#propertiesInfo").show();
	$("#outputInfo").hide();
}


function getBuildId(saveWorkStatus)
{
	ajaxClient.loadData('/getBuildID/', 'GET', {},
			function(jsondata){
				glbWorkId = jsondata.id;
				
				if(saveWorkStatus){
					previewGenerator();
				}
			}
		);
}

function previewGenerator()
{
	var steps = getBuildInfo(); //[{"FROM":"testagain:latest"},{"ADD":{"src":"aa","dest":"bb"}},{"CMD":"ccc"}];
	var htmlList = [];
	for(var i=0; i<steps.length; i+=1){
		var item = steps[i];
		for(var key in item){
			//console.log(key)
			var tmpl = "{0} {1}";
			if(key === "ADD"){
				tmpl = "{0} {1} {2}";
				htmlList.push(tmpl.format(key, item[key].src, item[key].dest));
			}else if(key === "#") {
			//handle comments
				var tmpcomment = item[key];
				tmpcomment = tmpcomment.split("\r\n").join("");
				tmpcomment = tmpcomment.replace(/\n/g,' ');
				console.log(tmpcomment);
				htmlList.push(tmpl.format(key, tmpcomment));
			}else {
				htmlList.push(tmpl.format(key, item[key]));
			}
		}
	}
	//console.log(htmlList)
	var previewText = htmlList.join(getJoinToken());

	$("#previewBody").val(previewText);
	
	// Save work status
	saveWorkStatus(steps);
}


function toAddRegistry(host, port, pushUser, pushPwd, pushEmail)
{
	ajaxClient.loadData('/addRegistry/', 'POST', 
			{host:host, port:port, pushuser:pushUser, passwd:pushPwd, email:pushEmail},
			function(jsondata){
				if(jsondata.errorcode == 0){
					loadRegistryList();				
				} else {
					$("#newRegPanel .err").text(jsondata.errormsg);
					// error handle
				}
			}
		);
	
}

function loadRegistryList()
{
	ajaxClient.loadData('/getRegistry/', 'GET', 
			{},
			function(jsondata){
				if(jsondata.errorcode == 0){
					var html = "";
					var tmpl =  '<div class="row reg-item">' +
									'<div class="col-xs-6 regHost">{0}<br/><span class="reg-comm">{3}</span></div>' +
									'<div class="col-xs-3 regPort">{1}</div>' +
									'<div class="col-xs-3 regEdit"><div attr="{2}" class="reg-edit"></div><div attr="{2}" class="reg-delete"></div></div>' +
								'</div>';
					
					var regList = jsondata.regList;
					console.log(regList);
					for(var i=0; i<regList.length; i+=1){
						var item = regList[i];
						html += tmpl.format(item.dns, item.port, item.id, item.pushuser);
					}
					$("#regList").html(html);
				} else {
					// error handle
				}
			}
		);
}

function deleteRegistry(regId)
{
	modalAlert("Delete Registry", 'Are you sure?', function(){
		console.log("delete")
	});
}


function toDeleteResource(item)
{
	var itemName = item.attr("attr");
	var itemResId = item.attr("itemid");
	var itemType = "registry";
	if( !item.hasClass("image")){
		itemType = "file";
		itemName = $(".item-tag", item).text();
	}
	modalAlert("Delete Resoure", "Delete {0} ?".format(itemName), function(){
		ajaxClient.loadData('/deleteResource/', 'POST', 
				{resid:itemResId, itemType:itemType},
				function(jsondata){
					hideModalAlert();
					if(jsondata.errorcode == 0){
						if(item.hasClass("itemClicked")){
							// clear properties
							$("#propertiesInfo").html("");
						}
						item.remove();
					} else {
						setTimeout(function(){
							modalAlert("Failed", jsondata.errormsg, function(){
								hideModalAlert();
							});
						}, 500);

						// error handle
					}
				}
			);
	});	
}

function toDeleteHistory(item)
{
	var itemName = item.attr("attr");
	var itemHistoryId = item.attr("historyid");
	var itemResId = item.attr("itemid");

	modalAlert("Delete History", "Delete {0} ?".format(itemName), function(){
		ajaxClient.loadData('/deleteHistory/', 'POST', 
				{historyid:itemHistoryId},
				function(jsondata){
					hideModalAlert();
					if(jsondata.errorcode == 0){
						if(item.hasClass("itemClicked")){
							// clear properties
							$("#propertiesInfo").html("");
						}
						item.remove();
					} else {
						setTimeout(function(){
							modalAlert("Failed", jsondata.errormsg, function(){
								hideModalAlert();
							});
						}, 500);

						// error handle
					}
				}
			);
	});	
}

function changeBaseImageFn (imageEle, isReplace){
	var cloneImg = imageEle.clone(true).addClass("stop-drag");
	if(isReplace){
		$("#content .image").remove();
	} else {
		imageEle.remove();
	}
	$("#content").prepend(cloneImg);
	setTimeout(function(){
		cloneImg.show();
		previewGenerator();
	}, 500);						
}

function CheckSourceType(selectValue)
{
	if(selectValue != "registry"){
		$("#autoPull").parent().hide();
		$("#urlImage").text("URL Name");
		$("#fileGroup").hide();
		$("#inputUrl").removeAttr("disabled");
		$("#disNameGroup").show();
		$("#gitGroup").hide();
		
		if(selectValue === "localfile"){
			$("#fileGroup").show();
			$("#inputUrl").attr("disabled", "disabled");
		} else if(selectValue === "github") {
			$("#gitGroup").show();
		}
	} else {
	    $("#autoPull").parent().show();
		$("#inputUrl").removeAttr("disabled");
		$("#fileGroup").hide();
		$("#autoPull").removeAttr("disabled");
		$("#urlImage").text("Image Name");
		$("#disNameGroup").hide();
	}
}

function editCmd(target)
{

	if(target.hasClass("cmd")){
		var targetAttr = target.attr("attr");
		if(targetAttr === "run"){
			
			modalAlert("Action RUN command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "cmd"){
			
			modalAlert("Action CMD command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "expose"){
			
			modalAlert("Action EXPOSE command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				var value = $("#runarea").val();
				if($.trim(value) == ""){
					setAlertErrMsg();
					return false;
				} else if(/^[0-9\s]+/.test($.trim(value)) === false || /[\n]/.test($.trim(value)) ) {
					setAlertErrMsg("Invalid ");
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "entrypoint"){
			
			modalAlert("Action ENTRYPOINT command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "volume"){
			
			modalAlert("Action VOLUME command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "user"){
			
			modalAlert("Action USER command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "workdir"){
			
			modalAlert("Action WORKDIR command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "onbuild"){
			
			modalAlert("Action ONBUILD command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "env"){
			
			modalAlert("Action ENV command", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				$(".item-comm", target).text($("#runarea").val());
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "comments"){
			
			modalAlert("Add comments", '<textarea id="runarea" class="form-control"></textarea>', function(){
				if($.trim($("#runarea").val()) == ""){
					setAlertErrMsg();
					return false;
				}
				//$(".item-comm", target).text($("#runarea").val());
				$(".item-comm", target).text($("#runarea").val().split("\r\n").join(""));				
				target.data('cmd', $("#runarea").val());
			}, "", 
			function(){
				//target.remove();
			});
		}else if(targetAttr === "add"){
			var bodyHtml = '<form class="form-horizontal" role="form">' + 
								'<div class="form-group">' +
								' <label for="inputSrc" class="col-sm-3 control-label">Source</label>' +
								'<div class="col-sm-9">' + 
								'<input type="text" class="form-control" id="inputSrc" placeholder="Source">' + 
								'</div></div>' +
								'<div class="form-group">' + 
								'<label for="inputDest" class="col-sm-3 control-label">Destination</label>' +
								'<div class="col-sm-9">' +
								'<input type="text" class="form-control" id="inputDest" placeholder="Destination">' +
								'</div></div></form>';
			
	
			modalAlert("Action ADD command", bodyHtml, function(){
				if($.trim($("#inputSrc").val()) == "" || $.trim($("#inputDest").val()) == ""){
					setAlertErrMsg("Source or Destination is required.");
					return false;
				}
				$(".item-tag", target).text("ADD");
				$(".item-comm", target).text($("#inputSrc").val() + " " + $("#inputDest").val());
				target.data('src', $("#inputSrc").val());
				target.data('dest', $("#inputDest").val());
	
			}, "", 
			function(){
				//target.remove();
			});
			
			$(".thumb-icon", target).addClass("file");
			
			var resId = target.attr("itemid");
			if(resId){
				var itemUrl = glbResource[resId].url;
				$("#inputSrc").val(itemUrl);
			}
		}
		
		if(targetAttr === "add"){
			$("#inputSrc").val(target.data('src'));
			$("#inputDest").val(target.data('dest'));
		} else {
			$("#runarea").val(target.data('cmd'));
		}
	}
}

function saveWorkStatus(steps)
{
	if(steps){
		syncSteps = JSON.stringify(steps);
		needSync = true;
	}
	
	if(needSync && syncStatus === "idle"){
		
		console.log("To sync");
		
		syncStatus = "running";
		needSync = false;
		
		ajaxClient.loadData('/saveWorkStatus/', 'POST', 
				{id:glbWorkId, repoName:glbRepository, tagName:glbTag, saveSteps:syncSteps},
				function(jsondata){
					syncStatus = "idle";
					if(needSync){
						saveWorkStatus();
					}
				});
	}
}

function loadWorkStatus()
{
	ajaxClient.loadData('/loadWorkStatus/', 'GET', 
			{},
			function(jsondata){
				if(jsondata.errorcode == 0){
					glbWorkId = jsondata.id;

					restoreWorkStatus(jsondata.steps[1], jsondata.repoName, jsondata.tagName)
										
				} else {
					getBuildId();
				}
			});
}

function restoreWorkStatus(steps, repoName, tagName, isHistory)
{
	console.log("To restore work status");
	console.log(steps);
	
	if(isHistory){
		$("#his-work-title .repo-dis").text(repoName + (tagName ? ":"+tagName : "" ));
		$("#his-work-title .mantainer-dis").text("");
	} else {
		glbRepository = repoName;
		glbTag = tagName;
		$("#work-title .repo-dis").text(glbRepository + (glbTag ? ":"+glbTag : "" ));
	}

	var tmpl = '<div class="window {0} ui-draggable jq-draggable-incontainer" attr="{1}" style="display: block;">' +
			    	'<div class="thumb-icon {2}"></div>' +
			    	'<div class="item-body"><span class="item-tag">{3}</span><span class="item-comm">{4}</span></div>' +
			    	'<div class="item-tool"><span class="delete"></span><span class="arrow-right"></span></div>' +
		    	'</div>';
	
	if(isHistory){
		$("#content-history").html("");
	} else {
		$("#content").html("");
	}
	
	for(var i=0; i<steps.length; i+=1){
		var step = steps[i];		
		var key = Object.keys(step)[0];
		
		var itemClass = "image stop-drag";
		var itemAttr = "";
		var itemDataCmd = "";
		var itemDataSrc = "";
		var itemDataDest = "";
		var itemIcon = "";
		var itemComm = "";
		var itemDisplay = "";
		
		if(key === "FROM"){			
			itemAttr = step[key];
			itemDisplay = step[key];
		} else if(key === "MAINTAINER"){
			var maintainer = step[key];
			
			if(isHistory){
				$("#his-work-title .mantainer-dis").text(maintainer);
			} else {
				$("#work-title .mantainer-dis").text(maintainer);
				glbMaintainer = maintainer;
			}

			
			continue;
		} else {
			itemClass = "cmd";
			itemAttr = key.toLowerCase();
			itemIcon = key.toLowerCase() + "-icon";
			itemDisplay = key;
			if(key === "ADD"){
				var addSrc = step[key].src;
				var addDest = step[key].dst;
				itemDataSrc = addSrc;
				itemDataDest = addDest;
				itemComm = addSrc + " " + addDest;
			} else {
				if(key === "#"){
					itemIcon = "comments-icon";
					itemAttr = "comments";
					itemDisplay = "Comments";
				}
				itemComm = step[key];
				itemDataCmd = step[key];
				
				if(key ==="RUN" && itemComm === enterContainerCmd){
					continue;
				}
			}
		}
		
		var html = tmpl.format(itemClass, itemAttr, itemIcon, itemDisplay, itemComm);
		var htmlItem = $(html);
		
		if(key === "ADD"){
			htmlItem.data("src", itemDataSrc);
			htmlItem.data("dest", itemDataDest);
		} else if(key !== "FROM") {
			htmlItem.data("cmd", itemDataCmd);
		}
		
		if(isHistory){
			$("#content-history").append(htmlItem);
		} else {
			$("#content").append(htmlItem);
		}
	}
	
	if(!isHistory){
		previewGenerator();
	}
	
}

function addGitHubRes(gitUrl, repoName, repoDescription)
{
	$("#inputUrl").val(gitUrl);
	$("#inputDisName").val(repoName);
	$("#inputComment").val(repoDescription);
	
	$("#modalGithub").modal('hide');
}


var gitResItemTmpl = '<li class="res-window repo-list-item" giturl="{0}">' +
						'<div class="div-add-btn">' +
							'<button type="button" class="btn btn-default btn-add-git-res">+</button>' +
						'</div>' +
						'<h3><span class="span-git-repo">{1}</span>' +
						'<span class="span-time">Updated <time is="relative-time" datetime="{2}" title="{5}">{2}</time></span>' +
						'<span class="span-language">{3}</span></h3>' +
						'<p class="repo-list-item-description">{4}</p>' +
						'</li>';

function searchResFromGithub(q, isSearchYourself, pageNum)
{
    var githubusername = $(".top-user-style[githubuser]").attr("githubuser");
	if(q === "" && isSearchYourself == false && !(githubusername == "" || githubusername == null)){
		return;
	}

	pageNum = pageNum ? pageNum : 1;
	ajaxClient.loadData('/searchGithub/', 'GET', {q:q,searchYourself:isSearchYourself, pageNum:pageNum, perPage:10},
		function(jsondata){
			if(jsondata.errorcode == 0){
				$("#githubResList").html("");
				
				var resHtml = "",
					totalCount = jsondata.totalCount
					
					
				var dataList = jsondata.data;
				for(var i=0; i < dataList.length; i++){
					var dataItem = dataList[i],
						gitUrl = dataItem.url,
						repoName = dataItem.full_name,
						updated = dataItem.updated_at,
						language = dataItem.language,
						description = dataItem.description ? dataItem.description : " ",
						isPrivate = dataItem["private"],
												
						localeTime = new Date(updated).toLocaleString()
					
					language = language ? language : "";
					
					if(isPrivate){
						gitUrl = gitUrl.replace("https://","https://access_token@");
					}
					
					var html = gitResItemTmpl.format(gitUrl, repoName, updated, language, description, localeTime);
					//console.log(html);
					resHtml += html;
				}
				
				$("#githubResList").html(resHtml);
				
				var	tmpPageCount = Math.ceil(totalCount/gitHubResPerPage),
					pageCount = tmpPageCount > gitHubResMaxPage ? gitHubResMaxPage : tmpPageCount;
					
				if(pageCount > 0){
					// update paginate
					$("#gitPaginate").paginate({
						count: pageCount,
						start: pageNum,
						display: 5,
						border: true,
						border_color: '#DDD',
						text_color : '#428BCA',
						background_color : '#FFF',
						border_hover_color : '#428BCA',
						text_hover_color : '#FFF',
						background_hover_color : '#428BCA',
						images : false,
						mouse : 'press',
						onChange: function(page){
							searchResFromGithub(q, isSearchYourself, page);
						}
					});
				} else {
					$("#gitPaginate").html("");
				}
				
			}
		}
	)	
}


