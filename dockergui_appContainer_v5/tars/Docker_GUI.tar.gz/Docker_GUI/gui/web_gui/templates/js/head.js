/*!
 * This file is part of the DockerGUI software
 * Copyright (c) 2014 Alex Zhong, Bob Chen
 * 
 * License: LGPLv3 (http://www.gnu.org/licenses/lgpl.html)
*/

var oldColor;
$(document).ready(function(){
    $("#btn_logout").click(function(){
    	window.location.href = '/logout/';
    });
 

	$("#btn_changePwd").click(function(){		
		var bodyHtml = '<form class="form-horizontal" role="form">' + 
		'<div class="form-group">' + 
		'<label for="useroldpwd" class="col-sm-5 control-label">Enter your current password:</label>' +
		'<div class="col-sm-7">' +
		'<input type="password" class="form-control" id="useroldpwd" placeholder="Password">' +
		'</div></div>'+		
		'<div class="form-group">' + 
		'<label for="userpwd" class="col-sm-5 control-label">Enter a new password:</label>' +
		'<div class="col-sm-7">' +
		'<input type="password" class="form-control" id="userpwd" placeholder="Password">' +
		'</div></div>'+
		'<div class="form-group">' + 
		'<label for="userpwd2" class="col-sm-5 control-label">Type it again:</label>' +
		'<div class="col-sm-7">' +
		'<input type="password" class="form-control" id="userpwd2" placeholder="Repeat Password">' +
		'</div></div></form>'

		modalAlert("Change password", bodyHtml, function(){
			//verify input
			var oldPwd = $.trim($("#useroldpwd").val());
			var newPwd = $.trim($("#userpwd").val());
			var newPwd2 = $.trim($("#userpwd2").val());

			if(oldPwd == ""){
				setAlertErrMsg("Please enter your old password.");
				return false;
			}
			if(newPwd != newPwd2){
				setAlertErrMsg("Please check that your passwords match and try again.");
				return false;
			}			
			
			ajaxClient.loadData('/changePwd/', 'POST', {useroldpwd:oldPwd,usernewpwd:newPwd},
					function(jsondata){
						console.log(jsondata)
						if(jsondata.errorcode != 0){
							setAlertErrMsg(jsondata.errormsg);

						} else {
							modalAlert("Success", "Please login with your new password next time.", function(){
								hideModalAlert();
							});
						}
					}
			)
			
			return false;
		});
	});     
    
	//Head menu state
	var url = window.location.href; 
	if(url.indexOf("index")>0)
	{
		$("#li_build").addClass("active");
	}
	else if(url.indexOf("repo")>0)
	{
		//alert("adfasdfasdf");
		$("#li_repo").addClass("active");
	}
	else if(url.indexOf("ssh")>0)
	{
		$("#li_ssh").addClass("active");
	}	
	else if(url.indexOf("help")>0)
	{
		$("#li_help").addClass("active");
	}
	
	
	//Feedback
	$("#showFeedback").click(function(){
		$("#feedbackModal input, #feedbackMsg").val("");
		$("#feedbackModal .rate-msg,#feedbackRes").text("");
		$("#feedbackModal .rate").removeClass("star-bad star-normal star-good star-on");
		$("#submitFeedback").removeClass("feedbacked").text("Submit");
	});
	
	
	$("#feedbackModal .rate").mouseover(function(){
		$("#feedbackModal .rate").removeClass("star-bad star-normal star-good").addClass("star-on");
		$("#feedbackModal .rate-msg").removeClass("star-bad star-normal star-good");
		$(this).nextAll().removeClass("star-on");
		var selectedItems = $("#feedbackModal .star-on");
		
		var starClass = "";
		var rateMsg = "";
		switch(selectedItems.length){
			case 1:
				starClass = "star-bad";
				rateMsg = "I don't like it at all!";
				break;
			case 2:
				starClass = "star-normal";
				rateMsg = "I don't like it.";
				break;
			case 3:
				starClass = "star-normal";
				rateMsg = "Just so so.";
				break;
			case 4:
				starClass = "star-good";
				rateMsg = "It's Good!";
				break;
			case 5:
				starClass = "star-good";
				rateMsg = "Perfect!";
				break;
			default:
				starClass = "star-good";
				rateMsg = "Perfect!";
				break;
		}
		
		selectedItems.addClass(starClass);
		$("#feedbackModal .rate-msg").addClass(starClass);
		$("#feedbackModal .rate-msg").text(rateMsg);
		enableFeedback();
	});
	
	$("#submitFeedback").click(function(){
		if($(this).hasClass("feedbacked")){
			$("#feedbackModal").modal("hide");
		} else {
			submitFeedback();
		}
	});
	
	$("#feedbackUsername, #feedbackEmail, #feedbackMsg").keyup(function(){
		enableFeedback();
	});
	
});

function enableFeedback()
{
	if($("#submitFeedback").hasClass("feedbacked")){
		$("#submitFeedback").removeClass("feedbacked").text("Submit");
	}
}

function submitFeedback()
{
	var username = $.trim($("#feedbackUsername").val());
	var email = $.trim($("#feedbackEmail").val());
	var rate = $("#feedbackModal .star-on").length || 5; // if no rate means the score is 5
	var comment = $.trim($("#feedbackMsg").val());
	
	ajaxClient.loadData('/feedback/', 'POST', {username:username, email:email, rate:rate, comment:comment},
		function(jsondata){
			$("#feedbackRes").text("Thanks for your feedback.");
			$("#submitFeedback").addClass("feedbacked").text("Close");
			
		}
	);
	
}

