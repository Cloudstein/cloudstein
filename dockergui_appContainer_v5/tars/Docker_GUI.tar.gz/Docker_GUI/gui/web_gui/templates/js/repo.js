/*!
 * This file is part of the DockerGUI software
 * Copyright (c) 2014 Alex Zhong, Bob Chen
 * 
 * License: LGPLv3 (http://www.gnu.org/licenses/lgpl.html)
*/

var glbRepo = {};
var glbHistory = {};
var glbRepository = "Undefined";
//var currId = "";	// use to build image
var lastRepoId = "";

var searchFocus = false;

var autoRefresh = false;
var autoRefreshInterval = 5000;

// use to clearInterval
var refreshTimer = "";

$(document).ready(function(){
	
	searchRepos();
	loadRegistryList();
	
	initPage();

	$("#searchRepo").click(function(){
		$("#repoBody").html("");
		searchRepos($("#repoInput").val());
	});
	   
    
//    $("#content").delegate(".jq-draggable-incontainer", "click", function(){
//    	$(".itemClicked").removeClass("itemClicked");
//    	$(this).addClass("itemClicked");
//    	
//    	showProperties($(this));
//    	
//    });
//    
//    $("#content").delegate(".delete", "click", function(ev){
//    	var item = $(this).parent().parent();
//    	if(item.hasClass("itemClicked")){
//    		// clear properties
//    		$("#propertiesInfo").html("");
//    	}
//    	item.remove();
//    	previewGenerator();
//    	ev.stopPropagation();
//    });
    
    $("#repoBody").delegate(".jq-draggable-outcontainer", "click", function(ev){
    	var repoName = $(this).attr("itemid");
    	$(".itemClicked").removeClass("itemClicked");
    	$(this).addClass("itemClicked");
    	showTags(repoName);
    	$("#repoTitle").text(repoName);
    	
    	lastRepoId = repoName;
    	ev.stopPropagation();
    });
        
    $("#tagContent").delegate(".tag-div ", "click", function(ev){
    	var item= $(this);
    	$(".tag-div").removeClass("active");
    	item.addClass("active");
    	
    	$(".tag-div:not(.active) .tag-title-div").removeClass("selected");
    	
    	//showProperties(item, true);
    	ev.stopPropagation();
    });
    
    $("#tagContent").delegate(".tag-div .tag-item", "click", function(ev){
    	var item= $(".tag-title-div", $(this));
    	$(".tag-title-div").removeClass("selected");
    	item.addClass("selected");
    	
    	showProperties($(this));
    	//ev.stopPropagation();
    });
    
    $("#tagContent").delegate(".tag-div .tag-del", "click", function(ev){
    	var selectedItem= $(".tag-title-div.selected", $(this).parent());
    	var resId = selectedItem.parent().attr("resid");
    	var tagLength = $(".tag-item", $(this).parent()).length;
    	//console.log($(".tag-item", $(this).parent()).length)
    	//console.log(typeof resId);
    	if(typeof resId !== "undefined"){
    		if(tagLength > 1){
    			deleteTag(resId);
    		} else {
    			confirmDeleteTag(resId);
    		}
    	}
    });

    $("#tagContent").delegate(".tag-div .tag-edit", "click", function(ev){
    	var selectedItem= $(".tag-title-div.selected", $(this).parent());
    	var resTag = selectedItem.parent().attr("tag");
    	var resName = selectedItem.parent().attr("resname");
    	var resRepo = selectedItem.parent().parent().parent().parent().attr("repo");
    	
    	if(typeof resTag !== "undefined"){
    		tagItem(resTag, resName, resRepo);
    	}
    });
    
    $("#regList").delegate(".panel .delete", "click", function(ev){
    	deleteRegistry($(this));
    });

//    $("#btn_registry").click(function(){
//    	loadRegistryList();
//    	$("#newRegPanel").hide();
//    	$("#modalRegistry").modal('show');
//    });

    $("#btnAddPanel").click(function(){
    	if($("#addRegPanel:visible").length){
    		$("#addRegPanel").hide();
    	} else {
    		$("#addRegPanel").show();
    	}
    });
    
    $("#hideRegPanel").click(function(){
    	$("#addRegPanel").hide();
    });
    
    $("#addRegistry").click(function(){
    	var host = $("#inputHost").val();
    	var port = $("#inputPort").val();
    	var pushUser = $("#inputPushUser").val();
    	var pushPwd = $("#inputPushPwd").val();
    	var pushEmail = $("#inputPushEmail").val();
    	
    	toAddRegistry(host, port, pushUser, pushPwd, pushEmail);
    });
    
    $("#btnPush").click(function(){
    	pushRepo();
    });
    
//    $("#regList").delegate(".reg-delete", "click", function(ev){
//    	return;
//    	var regId = $(this).attr("attr");
//    	deleteRegistry(regId);
//    });
//    
    // Search support Enter
    $("#repoInput").focusin(function(){
    	searchFocus = true;
    });
    $("#repoInput").blur(function(){
    	searchFocus = false;
    });
    $(window.document).keydown(function(ev){
    	if(ev.keyCode === 13 && searchFocus){
    		$("#searchRepo").click();
    		return false; // prevent browser-self event
    	}
    });
    
    
});

function initPage(){
	
}


function searchRepos(kw, callback)
{
	if(typeof kw === "undefined"){
		kw = "";
	}
	
	ajaxClient.loadData('/getRepos/', 'GET', {keyword:kw},
		function(jsondata){			
			var tmpl = '<div class="window jq-draggable-outcontainer {0}" itemid="{1}" >' +
		                '<div class="thumb-icon"></div>' +
						'<div class="item-body"><span class="item-tag">{1}</span><span class="item-comm"></span></div>' +
						'<div class="item-tool"><span class="delete"></span><span class="point-item">{2}</span></div>' +
					   '</div>';
			
			var resHtml = "";

			if(jsondata.errorcode == 0){	
				var repoList = jsondata.repos;
				glbRepo = repoList;
				for( var key in repoList){
					var item = repoList[key],
						divCss = "image", // image, file
						itemLength = Object.keys(item).length ,
						itemName = key;

					var html = tmpl.format(divCss, itemName, itemLength);
					resHtml += html;						
				}
				
			} else {
				// error handle
			}
			
			$("#repoBody").html(resHtml);
			if(typeof callback === "function"){
				callback();
			}
			
		}
	);
}


function showProperties(item)
{
	var itemId = item.attr("resname");

	var infoHtml = ""
	var tmpl = "";

	// item is image
	ajaxClient.loadData('/getProperty/', 'GET', {resid:itemId},
		function(jsondata){		
			if(jsondata.errorcode == 0){
				var info = jsondata.property;
								
				tmpl = "<div class='propAttr'><span class='prop-icon prop-author'></span><span class='prop-info'>{0}</span></div>" +
				"<div class='propAttr'><span class='prop-icon prop-id'></span><span class='prop-info'>{1}</span></div>" +
				"<div class='propAttr'><span class='prop-icon prop-date'></span><span class='prop-info'>{2}</span></div>" +
				"<div class='propAttr'><span class='prop-icon prop-size'></span><span class='prop-info'>{3}</span></div>";
				
				infoHtml = tmpl.format(info.author, info.id, new Date(info.created).toLocaleString(), JqConvertCapacity(info.Size));
			} else {
				infoHtml = "Failed to get properties."
			}
			
			$("#propertiesInfo").html(infoHtml);
		}
	);
}


function toAddRegistry(host, port, pushUser, pushPwd, pushEmail)
{
	$("#addRegPanel .err").text("");
	ajaxClient.loadData('/addRegistry/', 'POST', 
			{host:host, port:port, pushuser:pushUser, passwd:pushPwd, email:pushEmail},
			function(jsondata){
				if(jsondata.errorcode == 0){
					loadRegistryList();				
				} else {
					$("#addRegPanel .err").text(jsondata.errormsg);
				}
			}
		);
}

function loadRegistryList()
{
	ajaxClient.loadData('/getRegistry/', 'GET', 
			{},
			function(jsondata){
				if(jsondata.errorcode == 0){
					var html = "";
					var tmpl =  
							'<div class="panel panel-default" >' +
								'<div class="panel-heading">' +
									'<a class="reg-item collapsed" regid="{0}" href="#{0}" data-parent="#regList" data-toggle="collapse">' +
										'<div class="reg-name-div"><span class="point-item"></span></div><div class="reg-name-div"><span class="reg-name">{1}</span></div>' +
										'<div class="reg-tool"><span attr="{0}" class="delete"></span></div>' +
									'</a>' +
								'</div>' +
								'<div id="{0}" class="panel-collapse collapse ">' +
									'<div class="reg-info"><span class="reg-pushuser">{2}</span> is logged on</div>' +
								'</div>' +
							'</div>';
					
					var regList = jsondata.regList;
					console.log(regList);
					for(var i=0; i<regList.length; i+=1){
						var item = regList[i];
						html += tmpl.format(item.id, item.dns, item.pushuser);
					}
					$("#regList").html(html);
				} else {
					// error handle
				}
			}
		);
}

function deleteRegistry(regId)
{
	modalAlert("Delete Registry", 'Are you sure?', function(){
		console.log("delete")
	});
}


function toDeleteResource(item)
{
	var itemName = item.attr("attr");
	var itemResId = item.attr("itemid");
	var itemType = "registry";
	if( !item.hasClass("image")){
		itemType = "file";
		itemName = $(".item-tag", item).text();
	}
	modalAlert("Delete Resoure", "Delete {0} ?".format(itemName), function(){
		ajaxClient.loadData('/deleteResource/', 'POST', 
				{resid:itemResId, itemType:itemType},
				function(jsondata){
					hideModalAlert();
					if(jsondata.errorcode == 0){
						if(item.hasClass("itemClicked")){
							// clear properties
							$("#propertiesInfo").html("");
						}
						item.remove();
					} else {
						setTimeout(function(){
							modalAlert("Failed", jsondata.errormsg, function(){
								hideModalAlert();
							});
						}, 500);

						// error handle
					}
				}
			);
	});
}


function showTags(repoName)
{
	var tagGroup = glbRepo[repoName];
	console.log(tagGroup);
	
	var tagDivTpl = '<div class="tag-div" repo="{0}" repoid="{1}">' +
						'<div><span class="circle"></span></div>' +
						'<div class="tag-info">' +
							'<div class="tag-group">' +
							'{2}' +																	
							'</div>' +
							'<div class="tag-del"></div>' +
							'<div class="tag-edit"></div>' +
						'</div>' +
					'</div>';
	
	
	
	var tagItemTpl = '<div class="tag-item" resid="{0}" resname="{1}" tag={2}>' +
						'<div class="tag-img"></div>' +
						'<div class="tag-title-div"><span class="tag-title">{2}</span></div>' +
					 '</div>';
	
	var repoTagHtml = "";
	for(var tagGroupId in tagGroup){
		console.log(tagGroup[tagGroupId]);
		
		var tagHtml = "";
		var tagList = tagGroup[tagGroupId];
		for(var i=0; i<tagList.length; i+=1){
			var tagItem = tagList[i];
			tagHtml += tagItemTpl.format(tagItem.resid, tagItem.name,tagItem.tag);
		}
		//console.log(tagHtml)
		repoTagHtml += tagDivTpl.format(repoName, tagGroupId, tagHtml);
	}
	
	$("#tagContent .bg-line").html(repoTagHtml);
}

function confirmDeleteTag(resId)
{
	modalAlert("Delete Tag", "Image will delete, continue?", function(){
		deleteTag(resId, true);
		return false;
	});
}

function deleteTag(resId, deleteLast)
{
	ajaxClient.loadData('/deleteResource/', 'POST', 
			{resid:resId, itemType:"registry"},
			function(jsondata){
				if(deleteLast){
					hideModalAlert();
				}
				if(jsondata.errorcode == 0){					
					searchRepos("", function(){
						$(".bg-line").html("");
						$("#repoBody .jq-draggable-outcontainer[itemid='"+lastRepoId+"']").click();
					});
				} else {
					setTimeout(function(){
						modalAlert("Failed", jsondata.errormsg, function(){
							hideModalAlert();
						});
					}, 500);
					// error handle
				}
			}
		);
}

function tagItem(resTag, resName, resRepo)
{
	var bodyHtml = '<form class="form-horizontal" role="form">' + 
					'<div class="form-group">' +
					' <label for="inputSrc" class="col-sm-3 control-label">Source</label>' +
					'<div class="col-sm-9 src-tag">' + 
					'<span">{0}</span>' + 
					'</div></div>' +
					'<div class="form-group">' + 
					'<label for="inputDest" class="col-sm-3 control-label">New Repository</label>' +
					'<div class="col-sm-9">' +
					'<input type="text" class="form-control" id="inputNewRepo" value="{1}">' +
					'</div></div>' +
					'<div class="form-group">' +
					'<label class="col-sm-3 control-label" for="inputDest">New Tag Name</label>' +
					'<div class="col-sm-9">' +
					'<input type="text" id="inputNewTagName" class="form-control">' +
					'</div></div>' +
					'</form>';
	
	modalAlert("Tag Image", bodyHtml.format(resName, resRepo), function(){
		var newRepo = $.trim($("#inputNewRepo").val()),
			newTagName = $.trim($("#inputNewTagName").val())
		
    	if(/[^a-z0-9-_.]/.test(newRepo+newTagName)){
    		setAlertErrMsg("Repository or tag name only allow a-z0-9-_.");
    		return;
    	}	
		
		ajaxClient.loadData('/tagImage/', 'POST', 
				{resTag:resTag, resRepo:resRepo, newRepo:newRepo, newTagName:newTagName},
				function(jsondata){
					if(jsondata.errorcode == 0){
						hideModalAlert();
						searchRepos("", function(){
							$(".bg-line").html("");
							$("#repoBody .jq-draggable-outcontainer[itemid='"+lastRepoId+"']").click();
						});
					} else {
						setAlertErrMsg(jsondata.errormsg);
						//return false;
					}
				}
			);
		return false;
	});
}

function pushRepo()
{
	var repo = $("#repoBody .window.itemClicked").attr("itemid");//$("#tagContent .tag-div.active .tag-title-div.selected").parent().attr("resname");
	var registryId = $("#regList .reg-item:not(.collapsed)").attr("regid");
		
	if( !repo || !registryId){
		return;
	}
	console.log(repo);
	console.log(registryId);
	
	$("#btnPush").attr("disabled","disabled");
	
	ajaxClient.loadData('/pushRepo/', 'POST', 
			{repo:repo, regId:registryId},
			function(jsondata){
				//$("#btnPush").removeAttr("disabled");
				if(jsondata.errorcode == 0){
					searchRepos("", function(){
						$(".bg-line").html("");
						$("#repoBody .jq-draggable-outcontainer[itemid='"+lastRepoId+"']").click();
					});
					refreshTimer = window.setInterval(function(){
						console.log("check push status: " + repo)
						queryPushStatus(repo, registryId);
					},  autoRefreshInterval);
					
				} else {
					modalAlert("Failed", jsondata.errormsg, function(){
						hideModalAlert();
						return false;
					});
				}
			}
		);
}

function queryPushStatus(repo, registryId)
{
	ajaxClient.loadData('/pushStatus/', 'GET', 
			{repo:repo, regId:registryId},
			function(jsondata){
				//$("#btnPush").removeAttr("disabled");
				if(jsondata.errorcode == 0){
					var status = jsondata.status.status;
					
					if(status === "failed"){
						$("#btnPush").removeAttr("disabled");
						window.clearInterval(refreshTimer);
						modalAlert("Failed", "Push Failed.", function(){
							hideModalAlert();
							return false;
						});
					} else if (status === "running") {
						console.log("Push is running");
					} else if (status === "finished") {
						console.log("Push is finished");
						window.clearInterval(refreshTimer);
						$("#btnPush").removeAttr("disabled");
						
						modalAlert("Success", "Push finished.", function(){
							hideModalAlert();
							return false;
						});
					}
					
				} else {
					$("#btnPush").removeAttr("disabled");
					window.clearInterval(refreshTimer);
					modalAlert("Failed", jsondata.errormsg, function(){
						hideModalAlert();
						return false;
					});
				}
			}
		);
}

function deleteRegistry(regObj)
{
	var regId = regObj.attr("attr");
	modalAlert("Delete Registry", 'Delete this registry?', function(){
		ajaxClient.loadData('/deleteRegistry/', 'POST', 
				{regId:regId},
				function(jsondata){
					if(jsondata.errorcode == 0){
						loadRegistryList();
					} else {

					}
				}
			);
		hideModalAlert();
		return false;
	});
}
