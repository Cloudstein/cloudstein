/*!
 * This file is part of the DockerGUI software
 * Copyright (c) 2014 Alex Zhong, Bob Chen
 * 
 * License: LGPLv3 (http://www.gnu.org/licenses/lgpl.html)
*/

Array.prototype.contains = function(item){
   return RegExp("\\b"+item+"\\b").test(this);
};

String.prototype.format = function(){
	var args = arguments;
	return this.replace(/\{(\d+)\}/g,
		function(m,i){
			return args[i];
	});
};

//Date.prototype.convertLocaleTime = function(){
//	var year = this.getFullYear();
//	var month = this.getMonth() + 1;
//	var date = this.getDate();
//	var hour = this.getHours();
//	var minute = this.getMinutes();
//	var second = this.getSeconds();
//	if(month < 10){
//		month = "0" + month;
//	}
//	if(date < 10){
//		date = "0" + date;
//	}
//	if(hour < 10){
//		hour = "0" + hour;
//	}
//	if(minute < 10){
//		minute = "0" + minute;
//	}
//	if(second < 10){
//		second = "0" + second;
//	}
//	
//	return year + "-" + month + "-" + date + " " + hour + ":" + minute + ":" + second;
//};


/*
Array.prototype.containsKey(key)
{
	for(var item in this)
	{
		if(item == key)
		{
			return true;
		}
	}
	return false;
}
*/
function containsKey(arr, key)
{
	for(var item in arr)
	{
		if(item == key)
		{
			return true;
		}
	}
	return false;
}

// compute capacity
function JqConvertCapacity(capacity)
{
	try {
		if (capacity == "-1") {
			return "N/A"
		}
		
		var int_capacity = capacity * 1;
		var unit = 1024
		
		if (int_capacity == 0) {
			return "0 MB"
		}
		
		console.log(capacity)
		
		if (Math.floor(int_capacity / (unit * unit * unit * unit)) != 0) {
			return (int_capacity / (unit * unit * unit * unit)).toFixed(2) + " TB";
		}
		//num.toFixed(2)
		
		if (Math.floor(int_capacity / (unit * unit * unit)) != 0) {
			return (int_capacity / (unit * unit * unit)).toFixed(2) + " GB";
		}
		
		if (Math.floor(int_capacity / (unit * unit)) != 0) {
			return Math.round(int_capacity / (unit * unit)) + " MB";
		}
		
		if (Math.floor(int_capacity / (unit)) != 0) {
			return Math.round(int_capacity / (unit)) + " KB";
		}
		
		if (Math.floor(int_capacity) != 0) {
			return Math.round(int_capacity) + " B";
		}
	}
	catch(err)
	{
		return capacity
	}
}

/*
 * match : finded character
 * pos   : the character position
 * orginalText : original text
 * */
function HtmlEscape(str)
{
	//var escapeStr = "";
	return str.replace(/[<>"&]/g, function(match, pos, orginalText){
		switch(match){
			case "<":
				return "&lt;";
			case ">":
				return "&gt;";
			case "&":
				return "&amp;";
			case "\"":
				return "&quot;";
		}
	});
	//return escapeStr
}

//wipe off overlength string
function cutString(str, num)
{
	num = num*1;
	String.prototype.len=function(){return this.replace(/[^\x00-\xff]/g,"aa").length;} //count string actually length
	var orgLength = str.len();
	
	//var cutCount = 0;
	//var isUnicode = false;
	if(orgLength <= num)
	{
		return "<a class='str_short'>"+HtmlEscape(str)+"</a>";
	}
	else
	{
		var short_str = str.substring(0, num-3);
		var short_str_len = short_str.len();
		var loopCount = 1;
		
		while(short_str_len > num-3){
			short_str = short_str.substring(0, num-3-loopCount);
			short_str_len = short_str.len();
			loopCount++;
		}
		
		short_str += "...";
		return "<a class='str_short' title='"+str+"' >"+HtmlEscape(short_str)+"</a>";
	}
}

//Escape Jquery selector string
function jqEscape(str)
{
	try{
		var escapeStr = String(str)
	}
	catch(err){
		return str
	}
	
	return escapeStr.replace(/(:|\.|\$|\#|\]|\[|\)|\(|\/)/g, '\\$1');
}

//Jquery get brower type
function jqGetBrowerType()
{
	if(/msie/.test(navigator.userAgent.toLowerCase()) ){ return 'msie' }
	if(/firefox/.test(navigator.userAgent.toLowerCase()) ){ return 'mozilla' }
	if(/webkit /.test(navigator.userAgent.toLowerCase()) ){ return 'webkit ' }
	if(/opera/.test(navigator.userAgent.toLowerCase()) ){ return 'opera' }
	
	return 'unknow'
}

//Use to parse the returned xml by jquery ajax.
var JQXML ={
	ERROR_CODE:"errorcode",
	
	ERROR_MSG:"errormsg",
	
	//get the value of the key tag from xml/jquery
	getDataForXML:function(jqXml, key)
	{
		try
		{
			return jqXml.find(key)[0].firstChild.nodeValue;
		}
		catch(e)
		{
			return "";
		}
	},
	
	 //get the value of the key tag from xml/jquery
	getTextForXML:function(jqXml, key)
	{
		try
		{
			return jqXml.children(key).text();
		}
		catch(e)
		{
			return "";
		}
	}
}

/*$(document).ready(function (){
	//forbid right-hand button
	
	$(document).bind("contextmenu",function(e){
		return false;
	});
	
});*/

function modalAlert(title, bodyHtml, callBack, buttonOkText, cancelCallBack)
{
	var modalTitle = title || "";
	var buttonText = buttonOkText || "OK";
	
	$("#modalAlert .modal-title").html(modalTitle);
	$("#modalAlert .btn_ok").text(buttonText);
	
	$("#modalAlert .modal-body .body-content").html(bodyHtml);
	
	$("#modalAlert .btn_ok").unbind();
	$("#modalAlert .btn_ok").click(function(){
		if(callBack() !== false){
			previewGenerator(); // refresh docker file preview
			$("#modalAlert").modal('hide');
		}
	});
	
	$("#modalAlert .btn_cancel, #modalAlert .close").unbind();
	if(typeof cancelCallBack === "function"){
		$("#modalAlert .btn_cancel, #modalAlert .close").click(function(){
			cancelCallBack();
		});
		
	};
	
	$("#modalAlert .err").text("");
	
	$("#modalAlert").modal('show');
}

function hideModalAlert()
{
	$("#modalAlert").modal('hide');
}

function setAlertErrMsg(msg)
{
	var errMsg = msg || "Input is none.";
	$("#modalAlert .err").text(errMsg);
}


function showLoading(loadMsg, callBack){
	$("#modalLoading .loadingText").text(loadMsg);
	$("#modalLoading").modal('show');
	callBack();
}

function hideLoading(){
	$("#modalLoading").modal('hide');
}

function getJoinToken(){
	var joinToken = "\n";
	if(jqGetBrowerType() === "msie"){
		joinToken = rowList.join("\n\r");
	}
	return joinToken;
}

function formatOutput(outputList ,toHtml)
{
	var token = toHtml ? "<br />" : getJoinToken();
	
	var outputHtml = ""
	for(var i=0; i<outputList.length; i+=1){
		outputHtml += unescape(outputList[i].replace(/\\/g, "%")) + token;
	}
	
	return outputHtml;
}



//////////////////
//  Class
//////////////////

function extend2(Child, Parent) { 
	var p = Parent.prototype;
	var c = Child.prototype;
	for(var i in p) { 
		c[i]= p[i];
	}
	c.uber= p;
}
//
function BaseKeydownClass(){}
BaseKeydownClass.prototype.checkEnter = function(ev){
	if (ev.keyCode == 13) {
		try {
			if ($(ev.target).data("events")["click"]) {
				$(ev.target).click();
				return false;
			}
			return true;
		}
		catch (err) {
			return true;
		}
	}
}

extend2(LoginKeydownClass,BaseKeydownClass)
function LoginKeydownClass(){
	//extend(this,BaseKeydownClass);
	this.acceptKeydown = function(ev){		
		if (ev.keyCode == 13) {
			if ($('#dialog_change_pass').dialog('isOpen')) {
				$("#btn_save").click();
				return false;
			}

			if (!$('#dialog_change_pass').dialog('isOpen')) {
				$("#btn_login").click();
				return false;
			}
		}
	}
}

//extend2(SettingUserKeydownClass,BaseKeydownClass)
//function SettingUserKeydownClass(){
//	//extend(this,BaseKeydownClass);
//	this.acceptKeydown = function(ev){		
//		if (ev.keyCode == 13) {
//			if ($('#dialog_add').dialog('isOpen')) {
//				//$("#btn_save").click();
//				return false;
//			}
//			if ($('#dialog').dialog('isOpen')) {
//				//$("#btn_yes").click();
//				return false;
//			}			
//			if ($('#dialog_edit').dialog('isOpen')) {
//				//$("#btn_edit").click();
//				return false;
//			}
//			
//			if ($(ev.target).attr('id') == 'txt_type_search') {
//				alert('1')
//				$("#btn_type_search").click();
//				return false;
//			}
//		}
//	}
//}

function FactoryKeydown(type)
{
	var obj = null;
	
	switch(type)
	{
		case 'login':
			obj = new LoginKeydownClass();
			break;
//		case 'settingUser':
//			obj = new SettingUserKeydownClass();
//			break;
		case 'status':
		case 'share':
		case 'library':
		case 'setting':
			obj = null;
			break;
	}
	
	return obj;
}

function contextKeydown(type, ev){
//	alert(ev.keyCode)
	var keydownManager = FactoryKeydown(type);
//	var rs = keydownManager.checkEnter(ev)
//	alert(rs)
	if(keydownManager != null && keydownManager.checkEnter(ev) ){
		keydownManager.acceptKeydown(ev)
	}
}


