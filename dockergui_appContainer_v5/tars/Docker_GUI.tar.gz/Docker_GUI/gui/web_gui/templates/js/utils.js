/*!
 * This file is part of the DockerGUI software
 * Copyright (c) 2014 Alex Zhong, Bob Chen
 * 
 * License: LGPLv3 (http://www.gnu.org/licenses/lgpl.html)
*/

function is_valid_v4ip(ip)
{
	var regExp = /^((([0-9]?[0-9])|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))\.){3}(([0-9]?[0-9])|(1[0-9]{2})|(2[0-4][0-9])|(25[0-5]))$/;
	if (regExp.test(ip))
	{
		return true;
	}
		
	return false;
}
	
function is_valid_v6ip(ip)
{
	//var regExp = /^(?:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){7})|(?:(?!(?:.*[a-f0-9](?::|$)){8,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,6})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,6})?))|(?:(?:(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){5}:)|(?:(?!(?:.*[a-f0-9]:){6,})(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,4})?::(?:[a-f0-9]{1,4}(?::[a-f0-9]{1,4}){0,4}:)?))?(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}))$/i;
	var regExp = /^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/i;
	if (regExp.test(ip))
	{
		return true;
	}
	
	return false;
}

function is_valid_ipv6_prefix_lenght(prefix)
{
	var regExp = /^(([1-9][0-9]?)|(1[0-2][0-8]))$/i;
	if (regExp.test(prefix))
	{
		return true;
	}
	
	return false;
}
	
function is_blank(value)
{
	var regExp = /^\s*$/;
		
	if (regExp.test(value))
	{
		return true;
	}
		
	return false;
}

function is_start_end_with_space(value)
{
	var regExp1 = /^\s+\S+$/;
	var regExp2 = /^\s*\S+\s+$/;
		
	if (regExp1.test(value) || regExp2.test(value))
	{
		return true;
	}
		
	return false;
}
	
function is_numeric(value)
{
	var regExp = /^[0-9]+$/;
		
	if (regExp.test(value))
	{
		return true;
	}
		
	return false;
}

function is_length_enough(text, max, min)
{
	if ( text.length > max || text.length < min )
	{
		return false;
	}
	
	return true;
}


function is_valid_pasword( password )
{
	var regExp = /^([0-9a-zA-Z])+$/;
	
	if ( password.length > 16 || password.length < 5 )
	{
		return false;
	}

	if (regExp.test(password))
	{
		return true;
	}
	
	return false;
}


function is_valid_domain(domain)
{
	var regExp = /^([a-zA-Z0-9]+(-[a-zA-Z0-9])*)$|^(\.?[a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\.)+[a-zA-Z0-9]{1,}$/;
	
	if (regExp.test(domain))
	{
		var labels = domain.split(".");
		
		for(i = 0; i < labels.length; i ++)
		{
			// each label must be less than or equal to 63 characters
			if (labels[i].length > 63)
			{
				return false;
			}
		}
		
		return true;
	}

	return false;
	
}

function is_valid_smpt_server(server)
{
	var regExp = /^((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	
	if (regExp.test(server))
	{
		return true;
	}
	
	return false;
}

function is_valid_hostname(hostname)
{
	var regExp = /^([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*)+$/;

	// hostname must be less than or equal to 63 characters
	if (hostname.length > 63)
	{
		return false;
	}
	
	if (regExp.test(hostname))
	{
		return true;
	}
	
	return false;
}


function trim_string(str)
{
	return  str.replace(/(^[\s]*)|([\s]*$)/g, "");
}


function is_valid_email(email)
{
	//var regExp = /^(?:[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+\.)*[\w\!\#\$\%\&\'\*\+\-\/\=\?\^\`\{\|\}\~]+@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
	//var regExp = /^([^\s@,:"<>]+)@([^\s@,:"<>]+\.[^\s@,:"<>.\d]{2,}|(\d{1,3}\.){3}\d{1,3})$/i;
	var regExp = /^([^\s@,:"<>&'+\\]+)@([^\s@,:"<>&'+\\]+\.[^\s@,:"<>&'+\\\.\d]{2,}|(\d{1,3}\.){3}\d{1,3})$/i;
	
	if (regExp.test(email))
	{
		return true;
	}
	
	return false;
}

function is_valid_date(date)
{
	var result = null;
	var regExp = ( /^([0-3][0-9])\/([0-3][0-9])\/((?:[0-9]{2})[0-9]{2})$/ );
	var tempDate;
	
	// MM/DD/YYYY format
	if ( result = regExp.exec(date))
	{
		
		var dateObj = new Date(result[3], result[1] - 1, result[2] );

		var y = dateObj.getFullYear();
		var m = dateObj.getMonth() + 1;
		var d = dateObj.getDate();
		
		// convert the number to string
		m += "";
		d += "";
		
		if (m.length == 1)
		{
			m = "0" + m;
		}
		
		if (d.length == 1)
		{
			d = "0" + d;
		}
		
		tempDate =  m + "/" + d + "/" + y ;		

	}
	// DD.MM.YYYY format
	else 
	{
		regExp = ( /^([0-3][0-9])\.([0-3][0-9])\.((?:[0-9]{2})[0-9]{2})$/ );
		if ( result = regExp.exec(date))
		{
			
			var dateObj = new Date(result[3], result[2] - 1, result[1] );

			var y = dateObj.getFullYear();
			var m = dateObj.getMonth() + 1;
			var d = dateObj.getDate();
			
			// convert the number to string
			m += "";
			d += "";
			
			if (m.length == 1)
			{
				m = "0" + m;
			}
			
			if (d.length == 1)
			{
				d = "0" + d;
			}
			
			tempDate =  d + "." + m + "." + y ;		
		}

		// YYYY-MM-DD format
		else 
		{
			regExp = ( /^((?:[0-9]{2})[0-9]{2})-([0-3][0-9])-([0-3][0-9])$/ );
			if ( result = regExp.exec(date))
			{
				
				var dateObj = new Date(result[1], result[2] - 1, result[3] );
	
				var y = dateObj.getFullYear();
				var m = dateObj.getMonth() + 1;
				var d = dateObj.getDate();
				
				// convert the number to string
				m += "";
				d += "";
				
				if (m.length == 1)
				{
					m = "0" + m;
				}
				
				if (d.length == 1)
				{
					d = "0" + d;
				}
				
				tempDate =  y + "-" + m + "-" + d ;		
			}
			
		}
	}
	
	if (tempDate == date)
	{
		return true;
	}
	
	return false;
}


function is_valid_time(time)
{
/*	var regExp = ( /\b(1[0-2]|0[1-9]):([0-5][0-9]):([0-5][0-9])\b/ );
	
	if (regExp.test(time))
	{
		return true;
	}
*/
	// hh:mm:ss tt 12 hour
	var regExp = ( /^([0-1]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])\s*(AM|PM)$/ );

	if (regExp.test(time))
	{
		var values = regExp.exec(time);
		//values[1] = values[1] * 1;
		if( values[1] < 0 || values[1] > 12) return false;
		if( values[2] < 0 || values[1] > 59) return false;
		if( values[3] < 0 || values[1] > 59) return false;
		return true;
	}
	else
	{
		// hh:mm:ss 24hour
		regExp = ( /^([0-2]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$/ );
		values = regExp.exec(time);
		if (regExp.test(time))
		{
			if( values[1] < 0 || values[1] > 23) return false;
			if( values[2] < 0 || values[1] > 59) return false;
			if( values[3] < 0 || values[1] > 59) return false;
			return true;
		}	
	}
	return false;
}


//convert the date 
function convert_date_format(date)
{
	//fromat from MM/DD/YYYY to YYYY-MM-DD
	var regExp = /(\d{2})\/(\d{2})\/(\d{4})/;
	var values = regExp.exec(date);
	
	if (values != null && values.length > 3)
	{
		return values[3] + "-" +  values[1] + "-" + values[2];
	}
	
	//fromat from DD.MM.YYYY to YYYY-MM-DD
	var regExp = /(\d{2})\.(\d{2})\.(\d{4})/;
	var values = regExp.exec(date);
	
	if (values != null && values.length > 3)
	{
		return values[3] + "-" +  values[2] + "-" + values[1];
	}
	
	//fromat from DD.MM.YYYY to YYYY-MM-DD
	var regExp = /(\d{4})-(\d{2})-(\d{2})/;
	var values = regExp.exec(date);
	
	if (values != null && values.length > 3)
	{
		return values[1] + "-" +  values[2] + "-" + values[3];
	}	
	
	return '';

}

// convert time
function convert_time_format(time)
{
	var regExp = /(\d+):(\d+):(\d+)\s*(AM|PM)?/;
	var values = regExp.exec(time);
	
	//12 hours AM/PM format
	if (values != null && values.length > 4)
	{
		// if PM hours and not equal to 12 need to increase 12
		if (values[4] == 'PM')
		{
			if (parseInt(values[1]) == 12)
			{
				return values[1] + ":" +  values[2] + ":" + values[3];
			}
			return parseInt(values[1]) + 12  + ":" +  values[2] + ":" + values[3];
		}
		else if (values[4] == 'AM')
		{
			// if AM hours and equal to 12 need to set to 00 hours
			if (parseInt(values[1]) == 12)
			{
				return "00" + ":" +  values[2] + ":" + values[3];
			}
			return values[1] + ":" +  values[2] + ":" + values[3];
		}
		//24 hours format
		else
		{
			return values[1] + ":" +  values[2] + ":" + values[3];
		}		
	}
	
	//24 hours format
	if (values != null && values.length > 3)
	{
		return values[1] + ":" +  values[2] + ":" + values[3];
	}
	
	return '';
}

//convert time
function get_date_format(date, date_format)
{
	var default_date = convert_date_format(date);
	var new_date = date_format;
	
	//fromat YYYY-MM-DD
	var regExp = /(\d{4})-(\d{2})-(\d{2})/;
	var values = regExp.exec(default_date);
	
	if (values != null && values.length > 3)
	{
		new_date = new_date.replace(/YYYY/, values[1]);
		new_date = new_date.replace(/MM/, values[2]);
		new_date = new_date.replace(/DD/, values[3]);
		return new_date;		
	}		
	
	return default_date;
}

//convert time
function get_time_format(time, time_format)
{
	var hour24_time = convert_time_format(time);
	var new_time = time_format;
	
	//split time
	var regExp = /(\d+):(\d+):(\d+)?/;
	var values = regExp.exec(hour24_time);	
	var ampm = 'AM';


	if (values == null	)
	{
		return time;
	}
	

		
	//12hour clock
	if(time_format.indexOf('tt') > 0)
	{
		if (values.length > 1)
		{
			//make number
			values[1] = values[1] * 1;
			if( values[1] == 0)
			{
				values[1] = 12;
				ampm = 'AM';
			}
			else 
			{
				if( values[1] > 11 )
				{
					ampm = 'PM';
				}	
				if( values[1] > 12 )
				{
					values[1] = values[1] - 12;
				}
			}
			
			//make string
			values[1] += "";
			
			if (values[1].length == 1)
			{
				values[1] = "0" + values[1];
			}
			
		}
	}
	
	if (values != null && values.length > 3)
	{
		new_time = new_time.replace(/hh/, values[1]);
		new_time = new_time.replace(/mm/, values[2]);
		new_time = new_time.replace(/ss/, values[3]);
		new_time = new_time.replace(/tt/, ampm);
		return new_time;		
	}
	
	return hour24_time;
}

//check linux username
function checkUserName(name){
	var regExp = /^[a-zA-Z_][a-zA-Z0-9_.\-\$]{0,30}$/;
		
	if (regExp.test(name))
	{
		return true;
	}
	return false;
}

//check some address can use ip or domain name
function is_valid_domain_or_ipv4(value)
{
	var isNumber = false;
	
	var regExp = /^[0-9\.]+$/;
	if(regExp.test(value)){
		isNumber = true;
	}
	
	if(isNumber){
		if(is_valid_v4ip(value)){
			return true;
		}else{
			return false;
		}
	}
	
	if(value.length > 256){
		return false;
	}

	regExp = /^([0-9a-zA-Z][0-9a-zA-Z-]{0,62}\.)+([0-9a-zA-Z][0-9a-zA-Z-]{0,62})\.?$/;
	if (regExp.test(value)) {
		return true;
	}
	return false;
}