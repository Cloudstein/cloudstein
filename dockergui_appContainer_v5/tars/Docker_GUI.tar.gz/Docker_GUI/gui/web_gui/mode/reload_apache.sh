#!/bin/bash

/usr/sbin/apachectl graceful