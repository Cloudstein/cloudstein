/*!
 * This file is part of the DockerGUI software
 * Copyright (c) 2014 Alex Zhong, Bob Chen
 * 
 * License: LGPLv3 (http://www.gnu.org/licenses/lgpl.html)
*/

var pwdFocus = false;

$(document).ready(function(){
	$("#login").click(function(){		
		ajaxClient.loadData('/chklogin/', 'POST', {username:$("#username").val(), userpwd:$("#pwd").val()},
				function(jsondata){
					if(jsondata.errorcode != 0){
						modalAlert("Login Failed", jsondata.errormsg, function(){
							hideModalAlert();
						});
					} else {
						console.log(jsondata.redirect);
						window.location.href = jsondata.redirect;
					}
				}
		)
	});
	$("#register").click(function(){		
		var bodyHtml = '<form class="form-horizontal" role="form">' + 
		'<div class="form-group">' +
		' <label for="username" class="col-sm-4 control-label">My name is:</label>' +
		'<div class="col-sm-8">' + 
		'<input type="text" class="form-control" id="regUser" placeholder="Username">' + 
		'</div></div>' +
		'<div class="form-group">' + 
		'<label for="userpwd" class="col-sm-4 control-label">Enter a new password:</label>' +
		'<div class="col-sm-8">' +
		'<input type="password" class="form-control" id="userpwd" placeholder="Password">' +
		'</div></div>'+
		'<div class="form-group">' + 
		'<label for="userpwd2" class="col-sm-4 control-label">Type it again:</label>' +
		'<div class="col-sm-8">' +
		'<input type="password" class="form-control" id="userpwd2" placeholder="Repeat Password">' +
		'</div></div>'+
		'<div class="form-group">' +
		' <label for="email" class="col-sm-4 control-label">My e-mail address is:</label>' +
		'<div class="col-sm-8">' + 
		'<input type="text" class="form-control" id="email" placeholder="Email">' + 
		'</div></div>' +
		'<div class="form-group">' +
	    '<div class="col-sm-offset-4 col-sm-8">' +
		    '<div class="checkbox">' +
				'<label>' +
		          '<input id="agreement" type="checkbox" checked> Accept <a href="/agreement/" target="_blank">Docket Agreement</a>' +
		        '</label>' +
		      '</div>' +
		   '</div>' +
		  '</div>' +
		'</form>'

		modalAlert("Create new account", bodyHtml, function(){
			//verify input
			var regUser = $.trim($("#regUser").val());
			var regPwd = $.trim($("#userpwd").val());
			var regPwd2 = $.trim($("#userpwd2").val());
			var regEmail = $.trim($("#email").val());
			
			var agreement = $("#agreement").is(":checked");
			
			if(regUser == ""){
				setAlertErrMsg("You must provide a name.");
				return false;
			}
			if(regPwd == ""){
				setAlertErrMsg("Please enter your password.");
				return false;
			}
			if(regPwd != regPwd2){
				setAlertErrMsg("Please check that your passwords match and try again.");
				return false;
			}			
			if(regEmail != ""){
				var ret = is_valid_email(regEmail)
				if (ret == false) {
					setAlertErrMsg("Please check that your e-mail address and try again.");
					return false;				
				}
			}
			if(!agreement){
				setAlertErrMsg("Need accept Docket Agreement.")
				return false;
			}
			
			ajaxClient.loadData('/register/', 'POST', {reguser:regUser, userpwd:regPwd,useremail:regEmail},
					function(jsondata){
						console.log(jsondata)
						if(jsondata.errorcode != 0){
							setAlertErrMsg(jsondata.errormsg);

						} else {
							modalAlert("Success", "Please login with your new account", function(){
								hideModalAlert();
							});
						}
					}
			)
			
			return false;
		});
	});    
    $("#pwd").focusin(function(){
    	pwdFocus = true;
    });
    $("#pwd").blur(function(){
    	pwdFocus = false;
    });
    $(window.document).keydown(function(ev){
    	if(ev.keyCode === 13 && pwdFocus){
    		$("#login").click();
    		return false; // prevent browser-self event
    	}
    });
	
    
    $("#btnGithub").click(function(){
    	var bodyHtml = '<form class="form-horizontal" role="form">' + 
		'<div class="form-group">' +
	      '<div class="col-sm-offset-3 col-sm-9">' +
		    '<div class="checkbox">' +
				'<label>' +
		          '<input id="agreement" type="checkbox" checked> Accept <a href="/agreement/" target="_blank">Docket Agreement</a>' +
		        '</label>' +
		      '</div>' +
		   '</div>' +
		  '</div>' +
		'</form>';
    	
    	modalAlert("Sign in with Github", bodyHtml, function(){			
			var agreement = $("#agreement").is(":checked");
			var url = $("#btnGithub").attr("url");
			if(agreement){
				window.location.href = url;
			} else {
				setAlertErrMsg("Need accept Docket Agreement.");
				return false;
			}
			return false;
		});
    	
    });
    
});


